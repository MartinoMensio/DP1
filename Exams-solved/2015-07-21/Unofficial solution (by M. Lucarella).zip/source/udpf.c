#include "socklib.h"

SOCKET CreateSocketUDP() {
    SOCKET res = socket(AF_INET, SOCK_DGRAM, 0);
    if (res < 0) {
        fatalprint("socket creation error\n", res);
    }
    debugprint("new SOCKET created");
    return res;
}

int SendStringTo(SOCKET sock, const char* string, ADDRIN *addr, socklen_t addrl) {
    int len = strlen(string);
    int res;
    if (len != 0) {
        if(sock==0)
            res = sendto(currsock, string, len, 0, (ADDR*)addr, addrl);
        else
            res = sendto(sock, string, len, 0, (ADDR*)addr, addrl);

        if (res < 0) {
            errorprint("impossible to send string", res);
        } else {
            debugprint("string sended");
        }
        return res;
    }
    //void string
    return 0;
}

int RecvStringFrom(SOCKET sock, char* string, ssize_t maxsize, ADDRIN *addr, socklen_t* addrl) {
    int res;
    char c;
    if(sock==0)
        sock = currsock;

    res = recvfrom(sock, string, maxsize, MSG_PEEK, (ADDR*)addr, addrl);

    int i=0;
    while(1) {
        c = string[i];
        i++;
        if(c == '\n')
            break;
    }

    read(sock, NULL, i);

    if (res < 0) {
        errorprint("impossible to recv string", res);
    } else {
        if (strlen(string) >= maxsize) {
            string[res] = '\0';
        }
        debugprint("string received");
    }
    return res;
}

int TryRecvStringFrom(SOCKET sock, char* string, ssize_t maxsize, int ntry, ADDRIN* addr, socklen_t* addrl, int wtime) {
    int i=1;
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1; //impossible to wait

    while(1) {
        setupFdTimeval(wtime, sock, &cset, &tv);
        if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
            int res;
            if(sock==0)
                res = recvfrom(currsock, string, maxsize, 0, (ADDR*)addr, addrl);
            else
                res = recvfrom(sock, string, maxsize, 0, (ADDR*)addr, addrl);
            printf("%d", errno);
            if (res < 0) {
                errorprint("impossible to recv string", res);
            } else {
                if (strlen(string) >= maxsize) {
                    string[res] = '\0';
                }
                debugprint("string received");
                return res;
            }
        } else {
            i++;
            errorprint("time elapsed", -1);
            if(i>ntry)
                break;
        }
    }
    return -3;
}

int SendTo(SOCKET sock, void* buff, ssize_t size, ADDRIN* addr, socklen_t addrl) {
    int res;
    // EXAMPLE
    // sendto(my_socket, argv[3], strlen(argv[3]), 0, (struct sockaddr*) &address, sizeof(address));
    if(sock==0)
        res = sendto(currsock, buff, size, 0, (ADDR*)addr, addrl);
    else
        res = sendto(sock, buff, size, 0, (ADDR*)addr, addrl);

    if (res < 0) {
        errorprint("send error", errno);
    } else {
        debugprint("something sended");
    }
    return res;
}

int RecvFrom(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl) {
    int res;

    if(sock==0)
        res =  recvfrom(currsock, buff, maxsize, 0, (ADDR*)addr, addrl);
    else
        res = recvfrom(sock, buff, maxsize, 0, (ADDR*)addr, addrl);

//	printf("received\n");

    if (res < 0) {
        errorprint("impossible recv something", errno);
    } else {
        debugprint("something received");
    }
    return res;
}

int RecvFromDontWait(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl) {
    int res;
    if(sock ==0)
        res = recvfrom(currsock, buff, maxsize, MSG_DONTWAIT, (ADDR*)addr, addrl);
    else
        res = recvfrom(sock, buff, maxsize, MSG_DONTWAIT, (ADDR*)addr, addrl);

    if(errno != EAGAIN) { //means there are data but cannot read it
        if (res < 0) {
            errorprint("impossible recv something", res);
        } else {
            // debugprint("something received");
        }
    }
    return EAGAIN;
}

/* Try to recive a datagram using timeout and "ntry" number of retry */
int TryRecvFrom(SOCKET sock, void* buff, ssize_t maxsize, int ntry, ADDRIN* addr, socklen_t* addrl, int wtime) {
    int i=1;
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1; //impossible to wait

    while(1) {
        setupFdTimeval(wtime, sock, &cset, &tv);
        if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
            int res;
            if(sock==0)
                res = recvfrom(currsock, buff, maxsize, 0, (ADDR*)addr, addrl);
            else
                res = recvfrom(sock, buff, maxsize, 0, (ADDR*)addr, addrl);

            if (res < 0) {
                errorprint("impossible recv something", res);
                return res;
            } else {
                debugprint("something received");
            }
            return res;
        } else {
            i++;
            errorprint("no message received during wait", -2);
            if(i > ntry)
                break;
        }
    }
    return -1;
}

/* Try to recive a datagram using timeout */
/* Please set the timeout with "setMaxWait" */
int TryRecvFrom2(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl, int wtime) {
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1; //impossible to wait

    setupFdTimeval(wtime, sock, &cset, &tv);
    if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
        int res;
        if(sock==0)
            res = recvfrom(currsock, buff, maxsize, 0, (ADDR*)addr, addrl);
        else
            res = recvfrom(sock, buff, maxsize, 0, (ADDR*)addr, addrl);

        if (res < 0) {
            errorprint("impossible recv something", res);
            return res;
        } else {
            debugprint("something received");
        }
        return res;
    }
    debugprint("timeout expired");
    return -2; //timeout expired
}

int SendFileUDP(SOCKET sock, char* path, ssize_t chunksize, ADDRIN* addr, socklen_t addrl) {
    if(sock==0)
        sock = currsock;

    FILE* file = fopen(path, "r");

    fseek(file, 0L, SEEK_END);
    unsigned long size = ftell(file);
    fseek(file, 0L, SEEK_SET);
    printf("file size: %lu\n", size);

    unsigned long nsize = htonl(size);

    SendTo(sock, &nsize, sizeof(nsize), addr, addrl);
    char buf[100];
    RecvStringFrom(sock, buf, 100, addr, &addrl);
    printf("start file transfer\n");
    unsigned long comp=0;

    if (file != NULL) {
        char* chunk = (char*) malloc(chunksize+1);

        int readed=0;
        while (1) {

            readed = read(file->_fileno, chunk, chunksize);

            if(SendTo(sock, chunk, readed, addr, addrl) < 0) {
                printf("error sending\n");
                break;
            }

            comp+=readed;

            if (comp >= size) {
                printf("file sended!\n");
                break;
            }
        }
        free(chunk);
        fclose(file);

        return 1;
    }
    //file exist?
    errorprint("file don't exist or cannot be open", errno);
    return -1;
}

int RecvFileUDP(SOCKET sock, char* path, ssize_t chunksize, int ntry, ADDRIN* addr, socklen_t addrl) {
    if(sock==0)
        sock = currsock;

    unsigned long nsize, size;
    RecvFromDontWait(sock, &nsize, sizeof(nsize), addr, &addrl);
    size = ntohl(nsize);
    printf("file size: %lu\n", size);

    SendStringTo(sock, "R\r\n", addr, addrl);

    FILE* file = fopen(path, "w");
    if (file != NULL) {
        char* chunk = (char*) malloc(chunksize+1);
        int rec;

        unsigned long comp=0;

        while (1) {
            rec = read(sock, chunk, chunksize);
            write(file->_fileno, chunk, rec);
            comp+=rec;
            printf("%d%%\r", (int)((((double)comp)/((double)size))*100));

            if(comp >= size) {
                break;
            }
        }

        debugprint("file received!");
        fclose(file);
        free(chunk);
        return 1;
    }
    errorprint("impossible create file", errno);
    return -1;
}

SOCKET simple_UDPServer(int port) {
    ADDRIN saddr;
    SOCKET fd = CreateSocketUDP();
    setCurrSOCK(fd);
    setADDRIN(&saddr, AF_INET, port, INADDR_ANY);
    Bind(fd, &saddr);
    return fd;
}

SOCKET simple_UDPClient(ADDRIN* saddr, int port, char* addr) {
    SOCKET fd = CreateSocketUDP();
    setCurrSOCK(fd);
    setADDRIN(saddr, AF_INET, port, addr);
    return fd;
}

SOCKET simple_UDPClient_DNS(ADDRIN* saddr, int port, char* addr) {
    SOCKET fd = CreateSocketUDP();
    setCurrSOCK(fd);
    char* lu_address = Lookup_Host_tcp(addr);
    if(lu_address == NULL) {
        fatalprint("ip address or host name not valid", errno);
    }
    setADDRIN(saddr, AF_INET, port, lu_address);
    return fd;
}

char* Lookup_Host_udp (const char *host) {
    struct addrinfo hints, *res;
    char *first_ipv4_address = NULL;
    int errcode;
    char addrstr[100];
    void *ptr;
    int flag = 0;

    memset (&hints, 0, sizeof (hints));
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags |= AI_CANONNAME;

    errcode = getaddrinfo (host, NULL, &hints, &res);
    if (errcode != 0) {
        printf("getaddrinfo\n");
        return NULL;
    }

    printf ("Host: %s\n", host);
    while (res) {
        inet_ntop (res->ai_family, res->ai_addr->sa_data, addrstr, 100);

        switch (res->ai_family) {
        case AF_INET:
            ptr = &((struct sockaddr_in *) res->ai_addr)->sin_addr;
            inet_ntop (res->ai_family, ptr, addrstr, 100);
            if(flag == 0) {
                first_ipv4_address = strdup(addrstr);
                flag = 1;
            }
            break;
        case AF_INET6:
            ptr = &((struct sockaddr_in6 *) res->ai_addr)->sin6_addr;
            inet_ntop (res->ai_family, ptr, addrstr, 100);
            break;
        }

        printf ("IPv%d address: %s (%s)\n", res->ai_family == PF_INET6 ? 6 : 4,
                addrstr, res->ai_canonname);
        res = res->ai_next;
    }

    return first_ipv4_address;
}
