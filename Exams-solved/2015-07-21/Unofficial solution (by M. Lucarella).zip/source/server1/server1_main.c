#include <stdio.h>
#include <stdlib.h>
#include "../my_utils.h"
#include "../types.h"

#define BUFFER_LEN_MAX 200
#define QUEUE_LEN 10

int main(int argc, char* argv[]) {
    SOCKET socketServer, socketClient;
    bool_t bret;
    char buffer[BUFFER_LEN_MAX+1] = {'\0'};
    uint32_t file_len;
    FILE *fp;
    ADDRIN client_addr;
    XDR xdr_in, xdr_out;
    FILE *buff_in, *buff_out;
    response_msg my_response_msg;
    call_msg my_call_msg;

    // Arguments check
    if(argc != 2) {
        printf("Usage: %s <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Setup connecition
    socketServer = simple_TCPServer(atoi(argv[1]), INADDR_ANY, QUEUE_LEN);
    if(socketServer <= 0){
        return EXIT_FAILURE;
    }
    my_call_msg.call_msg_u.filename = (char*) malloc(128*sizeof(char));

    while(1) {
        // listen
        socketClient = Accept(socketServer, &client_addr, sizeof(client_addr));
        if(socketClient < 0) {
            printf("Client socket setup error\n");
            xdr_destroy(&xdr_in);
            xdr_destroy(&xdr_out);
            CloseSOCK(socketServer);
            free(my_call_msg.call_msg_u.filename);
            return EXIT_FAILURE;
        }

        buff_in = xdr_SocketOpen_read(&xdr_in, socketClient);
        buff_out = xdr_SocketOpen_write(&xdr_out, socketClient);

        printf("- Connection enstablished by: %s\n", inet_ntoa(client_addr.sin_addr));
        while(1) {
            printf("- Waiting for commands...\n");
            bret = xdr_call_msg(&xdr_in, &my_call_msg);
            if(bret == FALSE){
                printf("Receive error\n");
                CloseSOCK(socketClient);
                break;
            }

            if(my_call_msg.ctype == GET) {
                // GETfilename command
                if((fp = fopen(my_call_msg.call_msg_u.filename, "r")) == NULL) {
                    // File not found
                    printf("- File not found\n");
                    my_response_msg = ERR;
                    bret = xdr_response_msg(&xdr_out, &my_response_msg);
                    if(bret == FALSE){
                        printf("Send OK error\n");
                        CloseSOCK(socketClient);
                        break;
                    }
                    fflush(buff_out);
                } else {
                    printf("- File transfer (%s)... ", my_call_msg.call_msg_u.filename);
                    my_response_msg = OK;
                    bret = xdr_response_msg(&xdr_out, &my_response_msg);
                    fflush(buff_out);
                    if(bret == FALSE){
                        printf("Send OK error\n");
                        CloseSOCK(socketClient);
                        break;
                    }

                    file_len = fileSize(fp);
                    SendUNumber(socketClient, file_len);
                    while(fgets(buffer, BUFFER_LEN_MAX, fp) != NULL) {
                        SendString(socketClient, buffer);
                    }
                    printf("DONE\n");
                }
            } else {
                if(my_call_msg.ctype == QUIT) {
                    // QUIT command
                    printf("Connection closed by server\n");
                    CloseSOCK(socketClient);
                    break;
                } else {
                    // Wrong command
                    printf("Wrong command\n");
                    my_response_msg = ERR;
                    bret = xdr_response_msg(&xdr_out, &my_response_msg);
                    if(bret == FALSE){
                        printf("Send OK error\n");
                        CloseSOCK(socketClient);
                        break;
                    }
                    fflush(buff_out);
                }
            }
        }
    }
    // Close connection
    printf("Quitting...\n");
    xdr_destroy(&xdr_in);
    xdr_destroy(&xdr_out);
    CloseSOCK(socketServer);
    free(my_call_msg.call_msg_u.filename);

    return 0;
}
