/*
 * File:   utils.h
 */

#ifndef UTILS_H
#define	UTILS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "socklib.h"
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <rpc/xdr.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include "sys/types.h"

#define SEARCH_AT_START 1
#define SEARCH_AT_END 2
#define SEARCH_GLOBAL 3

int strClean(char* str, ssize_t buffsize);
int strAddHead(char* str, const char* head, ssize_t buffsize);
int strRemHead(char* str, const char* head);

int strAddTail(char* str, const char* tail, ssize_t buffsize);
int strRemTail(char* str, const char* tail);
int strAddTailCRLF(char* str, const char* tail, ssize_t buffsize);

int searchPatt(char* str, const char* patt, int special);
int checkFileExistence(const char* path);

void removePathFromFileName(char * string);
long int fileSize(FILE *fp);

void checkArgs(int argc, int n);

void childHandling();

FILE* xdr_FileOpen(XDR* xdr, SOCKET sock, const char* mode, int type);
FILE* xdr_SocketOpen_read(XDR* xdr, SOCKET sock);
FILE* xdr_SocketOpen_write(XDR* xdr, SOCKET sock);

#ifdef	__cplusplus
}
#endif

#endif	/* UTILS_H */

