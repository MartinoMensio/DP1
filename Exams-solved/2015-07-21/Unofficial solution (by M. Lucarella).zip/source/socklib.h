/*
 * File:   socklib.h
 */

#ifndef SOCKLIB_H
#define	SOCKLIB_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "unistd.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "sys/socket.h"
#include "arpa/inet.h"
#include "netinet/in.h"
#include "sys/types.h"
#include "sys/stat.h"
#include "sys/select.h"
#include "errno.h"
#include "sys/time.h"
#include <signal.h>
#include <netdb.h>

#define _DEBUG 1
#define INTERRUPTED_BY_SIGNAL (errno == EINTR || errno == ECHILD)

typedef int SOCKET;
typedef struct sockaddr_in ADDRIN;
typedef struct sockaddr ADDR;

//global variables
SOCKET currsock;

//COMMON FUNCTIONS
//create sock
SOCKET CreateSocketTCP();
SOCKET CreateSocketUDP();

void setCurrSOCK(SOCKET newsock);

//send & rcv TCP --> refering to GLOBAL CurrSOCK
int SendNumber(SOCKET sock, int num);
int RecvNumber(SOCKET sock, int* num);
int SendUNumber(SOCKET sock, uint32_t num);
int RecvUNumber(SOCKET sock, uint32_t* num);
int SendString(SOCKET sock, const char* string);
int RecvString(SOCKET sock, char* string, ssize_t maxsize);
int TryRecvString(SOCKET sock, char* string, ssize_t maxsize, int ntry, int wtime);
int Send(SOCKET sock, void* buff, ssize_t size);
int Recv(SOCKET sock,void* buff, ssize_t maxsize);
int RecvUntil(SOCKET sock, char* buff, ssize_t maxsize, char terminator);
int RecvNByte(SOCKET sock, uint8_t* buff, ssize_t maxsize, ssize_t data_num);
int RecvDontWait(SOCKET sock,void* buff, ssize_t maxsize);
int TryRecv(SOCKET sock,void* buff, ssize_t maxsize, int ntry, int wtime);
int TryRecv2(SOCKET sock,void* buff, ssize_t maxsize, int wtime);
int SendFile(SOCKET sock, char* path,ssize_t chunksize);
//int RecvFile(SOCKET sock, char* path, ssize_t chunksize, int ntry);
int SendFileNoSize(SOCKET sock, char *fileName);
int RecvFile(SOCKET sock, char* path, ssize_t chunksize);
int RecvFileNoSize(SOCKET sock, char *fileName);

//send & rcv UDP --> refering to a GLOBAL SOCK
int SendStringTo(SOCKET sock, const char* string, ADDRIN *addr, socklen_t addrl);
int RecvStringFrom(SOCKET sock, char* string, ssize_t maxsize, ADDRIN *addr, socklen_t* addrl);
int TryRecvStringFrom(SOCKET sock, char* string, ssize_t maxsize, int ntry, ADDRIN* addr, socklen_t* addrl, int wtime);
int SendTo(SOCKET sock, void* buff, ssize_t size, ADDRIN* addr, socklen_t addrl);
int RecvFrom(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl);
int RecvFromDontWait(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl);
int TryRecvFrom(SOCKET sock, void* buff, ssize_t maxsize, int ntry, ADDRIN* addr, socklen_t* addrl, int wtime);
int TryRecvFrom2(SOCKET sock, void* buff, ssize_t maxsize, ADDRIN* addr, socklen_t* addrl, int wtime);
int SendFileUDP(SOCKET sock, char* path, ssize_t chunksize, ADDRIN* addr, socklen_t addrl);
int RecvFileUDP(SOCKET sock, char* path, ssize_t chunksize, int ntry, ADDRIN* addr, socklen_t addrl);

//close socket
int CloseSOCK(SOCKET sock);
int shutdownWriteSOCK(SOCKET sock);
int shutdownReadSOCK(SOCKET sock);

void setupFdTimeval(int sec, SOCKET sock, fd_set *cset, struct timeval *tv);

void setADDRIN(ADDRIN* addr, int family, int port, char* naddr);

//SERVER SIDE FUNCTIONS
int Bind(SOCKET sock, ADDRIN* addr); //1
int Listen(SOCKET sock, unsigned int queuelen); //2
SOCKET Accept(SOCKET sock, ADDRIN* clientaddr, socklen_t size); //3

//CLIENT SIDE FUNCTIONS
int Connect(SOCKET sock, ADDRIN* addr);

//UTILS
int errorprint(const char*, int err);
void fatalprint(const char*, int err);
void debugprint(const char* str);

//easy function
SOCKET simple_TCPServer(int port, char* addr, int queuelen);
SOCKET simple_TCPClient(int port, char* addr);
SOCKET simple_TCPClient_DNS(int port, char* addr);

SOCKET simple_UDPServer(int port);
SOCKET simple_UDPClient(ADDRIN* saddr, int port, char* addr);
SOCKET simple_UDPClient_DNS(ADDRIN* saddr, int port, char* addr);

char * Lookup_Host_tcp (const char *host);
char * Lookup_Host_udp (const char *host);
//from stevenson
void Writen(int fd, void* ptr, size_t nbytes);
#ifdef	__cplusplus
}
#endif

#endif	/* SOCKLIB_H */

