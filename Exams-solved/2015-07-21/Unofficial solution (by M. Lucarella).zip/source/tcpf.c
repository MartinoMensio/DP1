/*
 * File:   tcpf.c
 */

#include "socklib.h"

SOCKET CreateSocketTCP() {
    SOCKET res = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (res < 0) {
        fatalprint("socket creation error\n", res);
    }
    debugprint("new SOCKET created");
    return res;
}

int SendNumber(SOCKET sock, int32_t num) {
    int32_t net_num = htonl(num);
    int res;
    if(sock==0)
        res = send(currsock, &net_num, sizeof(int32_t), 0);
    else
        res = send(sock, &net_num, sizeof(int32_t), 0);

    if (res < 0) {
        errorprint("impossible to send number", errno);
        //return errno;
    } else {
        debugprint("number sended");
    }

    return res;
}

int RecvNumber(SOCKET sock, int32_t* num) {
    int32_t net_num;
    int res;
    if(sock==0) {
        res = read(currsock, &net_num, sizeof(int32_t));
    } else {
        res = read(sock, &net_num, sizeof(int32_t));
    }

    num[0] = ntohl(net_num);

    if (res < 0) {
        errorprint("impossible to receive number", errno);
        //return errno;
    } else {
        debugprint("number received");
    }
    return res;
}

int SendUNumber(SOCKET sock, uint32_t num) {
    uint32_t net_num = htonl(num);
    int res;
    if(sock==0)
        res = send(currsock, &net_num, sizeof(uint32_t), 0);
    else
        res = send(sock, &net_num, sizeof(uint32_t), 0);

    if (res < 0) {
        errorprint("impossible to send number", errno);
        //return errno;
    } else {
        debugprint("U number sended");
    }

    return res;
}

int RecvUNumber(SOCKET sock, uint32_t* num) {
    uint32_t net_num;
    int res;
    if(sock==0) {
        res = read(currsock, &net_num, sizeof(uint32_t));
    } else {
        res = read(sock, &net_num, sizeof(uint32_t));
    }

    num[0] = ntohl(net_num);

    if (res < 0) {
        errorprint("impossible to receive number", errno);
        //return errno;
    } else {
        debugprint("U number received");
    }
    return res;
}

int SendString(SOCKET sock,const char* string) {
    int len = strlen(string);
    if (len != 0) {
        int res;
        if(sock==0)
            res = send(currsock, string, len, 0);
        else
            res = send(sock, string, len, 0);

        if (res < 0) {
            errorprint("impossible to send string", res);
        } else {
            debugprint("string sended");
        }
        return res;
    }
    //void string
    return 0;
}

int RecvString(SOCKET sock, char* string, ssize_t maxsize) {
    int res;
    char c = ' ';
    int i=0;

    if(sock==0) {
        do {
            res = read(currsock, &c, 1);
            if(c=='\0')
                break;
            string[i]=c;
            i++;

            if(i>= maxsize) {
                res = -1;
                break;
            }

        } while(res > 0);

    } else {
        do {
            res = read(sock, &c, 1);
            if(c=='\0' || c=='\n')
                break;
            string[i]=c;
            i++;

            if(i>= maxsize) {
                res = -1;
                break;
            }

        } while(res > 0);
    }
    if (res < 0) {
        errorprint("impossible to receive string", res);
    } else {
        if (strlen(string) >= maxsize) {
            string[res] = '\0';
        }
        debugprint("string received");
    }
    return res;
}

int TryRecvString(SOCKET sock,char* string, ssize_t maxsize, int ntry, int wtime) {
    int i=1;
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1;

    while(1) {
        setupFdTimeval(wtime, sock, &cset, &tv);
        if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
            int res;
            if(sock==0)
                res = recv(currsock, string, maxsize, 0);
            else
                res = recv(sock, string, maxsize, 0);

            if (res < 0) {
                errorprint("impossible to recv string", res);
            } else {
                if (strlen(string) >= maxsize) {
                    string[res] = '\0';
                }
                debugprint("string received");
                return res;
            }
        } else {
            i++;
            errorprint("time elapsed", -1);
            if(i>ntry)
                break;
        }
    }
    return -1;
}

int Send(SOCKET sock, void* buff, ssize_t size) {
    int res;
    if(sock == 0)
        res = send(currsock, buff, size, 0);
    else
        res = send(sock, buff, size, 0);

    if (res < 0) {
        errorprint("sending error", res);
    } else {
        debugprint("something sended");
    }
    return res;
}

int Recv(SOCKET sock, void* buff, ssize_t maxsize) {
    int res;
    if(sock==0)
        res = recv(currsock, buff, maxsize, 0);
    else
        res = recv(sock, buff, maxsize, 0);

    if (res < 0) {
        errorprint("receiving error", res);
    } else {
        debugprint("something received");
    }
    return res;
}

int RecvNByte(SOCKET sock, uint8_t* buff, ssize_t maxsize, ssize_t data_num) {
    size_t res, received=0;
    if(maxsize < data_num) {
        return -1;
    }
    while(data_num > 0) {
        if(sock==0)
            res = recv(currsock, buff+received, data_num, 0);
        else
            res = recv(sock, buff+received, data_num, 0);
        if (res <= 0) {
            errorprint("receiving error", res);
            return res;
        }
        data_num -= res;
        received += res;
    }
    return data_num;
}

int RecvUntil(SOCKET sock, char* buff, ssize_t maxsize, char terminator) {
    ssize_t received=0;
    size_t res;
    if(maxsize < 1) {
        return -1;
    }

    while (received < maxsize-1) {
        if(sock==0)
            res = recv(currsock, buff+received, 1, 0);
        else
            res = recv(sock, buff+received, 1, 0);
        if (res <= 0) {
            errorprint("receiving error", res);
            return res;
        }
        if((buff+received)[0] == terminator) {
            received++;
            (buff+received)[0] = '\0';
            break;
        }
        received++;
    }
    return received;
}

int RecvDontWait(SOCKET sock,void* buff, ssize_t maxsize) {
    int res;
    if(sock==0)
        res = recv(currsock, buff, maxsize, MSG_DONTWAIT);
    else
        res = recv(sock, buff, maxsize, MSG_DONTWAIT);

    if(errno != EAGAIN) { //means there are data but cannot read it
        if (res < 0) {
            errorprint("impossible recv something", res);
        } else {
            debugprint("something received");
        }
    }
    return EAGAIN;
}

int TryRecv(SOCKET sock, void* buff, ssize_t maxsize, int ntry, int wtime) {
    int i=1;
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1; //impossible to wait

    while(1) {
        setupFdTimeval(wtime, sock, &cset, &tv);
        if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
            int res = recv(currsock, buff, maxsize, 0);

            if (res < 0) {
                errorprint("impossible recv something", res);
                return res;
            } else {
                debugprint("something received");
            }
            return res;
        } else {
            i++;
            errorprint("no message received during wait", -2);
            if(i > ntry)
                break;
        }
    }
    return -1;
}

int TryRecv2(SOCKET sock, void* buff, ssize_t maxsize, int wtime) {
    fd_set cset;
    struct timeval tv;
    if(wtime < 0)
        return -1; //impossible to wait

    setupFdTimeval(wtime, sock, &cset, &tv);
    if(select(FD_SETSIZE, &cset, NULL, NULL, &tv)) {
        int res = recv(currsock, buff, maxsize, 0);

        if (res < 0) {
            errorprint("impossible recv something", res);
            return res;
        } else {
            debugprint("something received");
        }
        return res;
    }
    debugprint("timeoutexpired");
    return -2;
}

void handle_sigpipe(int sig) {
    CloseSOCK(0);
    printf("broken PIPE\n Connection with client closed\n");
}

int SendFile(SOCKET sock, char* path, ssize_t chunksize) {
    FILE* file = fopen(path, "rb");
    setCurrSOCK(sock);
    signal(SIGPIPE, handle_sigpipe);

    if (file != NULL) {
        struct stat file_stat;
        fstat(file->_fileno, &file_stat);
        uint32_t size =  file_stat.st_size;

        printf("file size: %d\n", size);

        //unsigned long nsize = htonl(size);
        uint32_t nsize = htonl(size);
        Send(sock, &nsize, sizeof(nsize));
        //char buf[100];
        //RecvString(sock, buf, 100);

        printf("start file transfer\n");

        char* chunk = (char*) malloc(chunksize+1);
        unsigned long comp=0;
        unsigned long readed=0;

        while (1) {
            readed = read(file->_fileno, chunk, chunksize);
            comp+=readed;
            printf("debug %lu\n", readed);
            if(Send(sock, chunk, readed) < 0) {
                break;
            }
            if (comp >= size) {
                break;
            }
        }

        //flush socket
        lseek(currsock, 0, SEEK_END);
        free(chunk);
        fclose(file);

        return 1;
    }
    //file exist?
    errorprint("file don't exist or cannot be open", errno);
    return -1;
}

int SendFileNoSize(SOCKET sock, char *fileName) {
    char c;
    int rec;
    printf("%s\n", fileName);
    FILE *file = fopen(fileName, "rb");

    if (file == NULL) {
        errorprint("impossible open file", errno);
        return -1;
    }

    while (1) {
        rec = fread(&c, sizeof(char), 1, file);
        if(rec < 0) {
            fprintf(stderr, "Fatal read error!\n");
            return -1;
        }
        if(rec == 0)
            break;

        Send(sock, &c, sizeof(char));

    }
    printf("%s-->file sended!\n", fileName);
    fclose(file);
    return 1;
}

int RecvFile(SOCKET sock, char* path, ssize_t chunksize) {
    FILE* file = fopen(path, "wb");

    if (file != NULL) {
        char* chunk = (char*) malloc(chunksize+1);
        int rec;

        //unsigned long nsize, size;
        uint32_t nsize, size;
        Recv(sock, &nsize, sizeof(nsize));
        size = ntohl(nsize);
        printf("file size: %d\n", size);

        //SendString(sock, "R\r\n");

        unsigned long comp=0;
        double val;
        while (1) {
            rec = Recv(sock, chunk, chunksize);
            write(file->_fileno, chunk, rec);

            comp+=rec;

            if(comp>=size) {
                break;
            }

            val = 100.0*(((double)comp)/((double)size));
            printf("%s-->%d%%\r",path,(int)val);
        }
        printf("\n");
        printf("%s-->file received!\n", path);
        fclose(file);
        free(chunk);
        return 1;
    }
    errorprint("impossible create file", errno);
    return -1;
}

int RecvFileNoSize(SOCKET sock, char *fileName) { //char per char
    char c;
    int rec;
    FILE *file = fopen(fileName, "wb");

    if (file != NULL) {
        while (1) {
            rec = Recv(sock, &c, sizeof(char));
            if(rec < 0)
                return -1;

            if(rec == 0)
                break;

            fwrite(&c, sizeof(char), 1, file);
        }
        printf("%s-->file received!\n", fileName);
        fclose(file);
        return 1;
    }

    errorprint("impossible create file", errno);
    return -1;
}

int Listen(SOCKET sock, unsigned int queuelen) {
    int ret=-1;
    if(sock == 0)
        ret = listen(currsock, queuelen);
    else
        ret = listen(sock, queuelen);

    if (ret < 0) {
        errorprint("impossible to start listening on socket", errno);
        return errno;
    }
    debugprint("server start to listen");
    return ret;
}

int Bind(SOCKET sock, ADDRIN* addr) {
    int ret=-1;
    if(sock==0)
        ret = bind(currsock, (ADDR*) addr, sizeof (ADDRIN));
    else
        ret = bind(sock, (ADDR*) addr, sizeof (ADDRIN));

    if (ret < 0)
        fatalprint("impossible to bind address", ret);
    debugprint("address correctly binded");
    return ret;
}

SOCKET Accept(SOCKET sock, ADDRIN* cliaddr, socklen_t size) {
    bzero(cliaddr, size);
    debugprint("waiting for new connection");
    SOCKET new;

    if (sock==0)
        new = accept(currsock, (ADDR*) cliaddr, &size);
    else
        new = accept(sock, (ADDR*) cliaddr, &size);

    if (new < 0) {
        errorprint("impossible to accept new connection", errno);
        return -1;
    }
    return new;
}

int Connect(SOCKET sock, ADDRIN* addr) {
    socklen_t len = sizeof (ADDRIN);
    int ret;
    if(sock==0)
        ret = connect(currsock, (ADDR*) addr, len);
    else
        ret = connect(sock, (ADDR*) addr, len);

    if (ret < 0) {
        fatalprint("impossible to connect", errno);
    }
    debugprint("connected to server");
    return ret;
}

SOCKET simple_TCPServer(int port, char* addr, int queuelen) {
    ADDRIN saddr;
    SOCKET fd = CreateSocketTCP();
    setCurrSOCK(fd);
    setADDRIN(&saddr, AF_INET, port, addr);
    printf("DEBUG\n");
    Bind(fd, &saddr);
    Listen(fd, queuelen);
    return fd;
}

SOCKET simple_TCPClient(int port, char* addr) {
    ADDRIN saddr;
    SOCKET fd = CreateSocketTCP();
    setCurrSOCK(fd);
    setADDRIN(&saddr, AF_INET, port, addr);
    printf("Connecting to -> %s:%d\n", addr, port);
    Connect(fd, &saddr);

    return fd;
}

SOCKET simple_TCPClient_DNS(int port, char* addr) {
    ADDRIN saddr;
    SOCKET fd = CreateSocketTCP();
    setCurrSOCK(fd);
    char* lu_addr = Lookup_Host_tcp(addr);
    if(lu_addr == NULL) {
        fatalprint("ip address or host name not valid", errno);
    }
    setADDRIN(&saddr, AF_INET, port, lu_addr);
    Connect(fd, &saddr);

    return fd;
}

/*
   In case of success, it returns the FIRST valid IP address in dotted decimal notation as char * format bounded to the specified domain name
   In case no IP address is found, it returns NULL.
*/
char * Lookup_Host_tcp (const char *host) {
    struct addrinfo hints, *res;
    char *first_ipv4_address = NULL;
    int errcode;
    char addrstr[100];
    void *ptr;
    int flag = 0;

    memset (&hints, 0, sizeof (hints));
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags |= AI_CANONNAME;

    errcode = getaddrinfo (host, NULL, &hints, &res);
    if (errcode != 0) {
        printf("getaddrinfo\n");
        return NULL;
    }

    printf ("Host: %s\n", host);
    while (res) {
        inet_ntop (res->ai_family, res->ai_addr->sa_data, addrstr, 100);

        switch (res->ai_family) {
        case AF_INET:
            ptr = &((struct sockaddr_in *) res->ai_addr)->sin_addr;
            inet_ntop (res->ai_family, ptr, addrstr, 100);
            if(flag == 0) {
                first_ipv4_address = strdup(addrstr);
                flag = 1;
            }
            break;
        case AF_INET6:
            ptr = &((struct sockaddr_in6 *) res->ai_addr)->sin6_addr;
            inet_ntop (res->ai_family, ptr, addrstr, 100);
            break;
        }

        printf ("IPv%d address: %s (%s)\n", res->ai_family == PF_INET6 ? 6 : 4,
                addrstr, res->ai_canonname);
        res = res->ai_next;
    }

    return first_ipv4_address;
}
