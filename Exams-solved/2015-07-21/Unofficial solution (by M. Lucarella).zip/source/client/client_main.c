#include <stdio.h>
#include <stdlib.h>
#include "../my_utils.h"
#include "../types.h"

#define BUFFER_LEN_MAX     200
#define FILENAME_MAX_SIZE  200+1

int main(int argc, char* argv[]) {
    SOCKET socketClient;
    int ret;
    bool_t bret;
    uint32_t num_bytes;
    char buffer[BUFFER_LEN_MAX+1] = {'\0'};
    FILE *fp;
    XDR xdr_in, xdr_out;
    FILE *buff_in, *buff_out;
    response_msg my_response_msg;
    call_msg my_call_msg;

    // Arguments check
    if(argc != 4) {
        printf("Usage: %s <address> <port> <filename>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Setup connecition
    socketClient = simple_TCPClient(atoi(argv[2]), argv[1]);
    if(socketClient<=0) {
        return EXIT_FAILURE;
    }

    buff_in = xdr_SocketOpen_read(&xdr_in, socketClient);
    buff_out = xdr_SocketOpen_write(&xdr_out, socketClient);

    // Input command
    printf("- CONNECTED\n");
    my_call_msg.ctype = GET;
    my_call_msg.call_msg_u.filename = argv[3];

    // Send command
    printf("- Request file: %s", argv[3]);
    bret = xdr_call_msg(&xdr_out, &my_call_msg);
    if(bret == FALSE) {
        printf("Send error\n");
        xdr_destroy(&xdr_in);
        xdr_destroy(&xdr_out);
        CloseSOCK(socketClient);
        return EXIT_FAILURE;
    }
    fflush(buff_out);

    // Recive data
    printf("- Waiting for reply...\n");
    bret = xdr_response_msg(&xdr_in, &my_response_msg);
    if(bret == FALSE) {
        printf("Send OK error\n");
        xdr_destroy(&xdr_in);
        xdr_destroy(&xdr_out);
        CloseSOCK(socketClient);
        return EXIT_FAILURE;
    }
    if(my_response_msg == OK) {
        // file found
        printf("- File found, starting trasmission...\n");
        // File length conversion
        ret = RecvUNumber(socketClient, &num_bytes);
        if(ret <= 0) {
            printf("Receive filesize error\n");
            xdr_destroy(&xdr_in);
            xdr_destroy(&xdr_out);
            CloseSOCK(socketClient);
            return EXIT_FAILURE;
        }
        printf("- File size: %d\n", num_bytes);

        // Create file
        if((fp = fopen(argv[3], "w")) == NULL) {
            printf("File error");
            xdr_destroy(&xdr_in);
            xdr_destroy(&xdr_out);
            CloseSOCK(socketClient);
            return EXIT_FAILURE;
        }

        // Write file
        while(num_bytes > 0) {
            ret = Recv(socketClient, buffer, BUFFER_LEN_MAX);
            if(ret <= 0) {
                printf("Receive failure");
                xdr_destroy(&xdr_in);
                xdr_destroy(&xdr_out);
                CloseSOCK(socketClient);
                return EXIT_FAILURE;
            }
            buffer[ret] = '\0';
            num_bytes -= ret;

            fputs(buffer, fp);
        }
        fclose(fp);
    } else {
        if(my_response_msg == ERR) {
            printf("File not found\n");
        } else {
            printf("Protocol error: \"%s\"\n", buffer);
            xdr_destroy(&xdr_in);
            xdr_destroy(&xdr_out);
            CloseSOCK(socketClient);
            return EXIT_FAILURE;
        }
    }

    // Quit procedure
    printf("\n-Quitting...\n");
    my_call_msg.ctype = QUIT;
    bret = xdr_call_msg(&xdr_out, &my_call_msg);
    if(bret == FALSE) {
        printf("Send error\n");
        xdr_destroy(&xdr_in);
        xdr_destroy(&xdr_out);
        CloseSOCK(socketClient);
        return EXIT_FAILURE;
    }
    fflush(buff_out);

    // Close connection
    xdr_destroy(&xdr_in);
    xdr_destroy(&xdr_out);
    CloseSOCK(socketClient);

    return 3;
}
